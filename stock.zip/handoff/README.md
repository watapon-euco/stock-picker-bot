# Stock Picker Bot — Editorial Dark テンプレート引き継ぎパッケージ

## 中身

- `src/templates/` — リポジトリの `src/templates/` にそのまま配置する4ファイル
  - `report_template.html` — 月次レポート
  - `performance_template.html` — パフォーマンスダッシュボード
  - `weekly_flash_template.html` — 週次速報
  - `styles.css` — 共有デザインシステム
- `preview/` — ローカルブラウザで開く確認用プレビュー（リポジトリには入れない）
- `CLAUDE_CODE_PROMPT.md` — Claude Code に渡す指示プロンプト
- `templates_README.md` — テンプレート設計メモ（プレースホルダー一覧、クラス名一覧）

## 使い方

1. `src/templates/` 配下4ファイルをリポジトリの `src/templates/` にコピー → 一度コミット & プッシュ
2. Claude Code に `CLAUDE_CODE_PROMPT.md` の「プロンプト本文」部分を貼り付け
3. Python 側の刷新を Claude Code に任せる

## ローカル確認

`preview/preview_monthly.html` などをブラウザで直接開くとサンプルデータ入りのレポートが見られます。
