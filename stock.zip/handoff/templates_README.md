# テンプレート設計メモ

このフォルダは `stock-picker-bot` リポジトリの `src/templates/` に差し込む、Editorial Dark テーマの新テンプレート3種一式です。

## ファイル構成

```
templates/
├── styles.css                   ← 共有デザインシステム（必ず一緒にdocs/に配置）
├── report_template.html         ← 月次レポート（src/step2_report.py）
├── performance_template.html    ← パフォーマンスダッシュボード（src/step6_backtest.py）
├── weekly_flash_template.html   ← 週次速報（src/step_weekly_flash.py）
├── preview_monthly.html         ← 月次プレビュー（サンプルデータ埋め込み）
├── preview_performance.html     ← パフォーマンスプレビュー
├── preview_weekly.html          ← 週次プレビュー
└── README.md                    ← この文書
```

## 統合手順

### 1. ファイル配置
```bash
# テンプレートを置き換え
cp templates/report_template.html         <repo>/src/templates/
cp templates/performance_template.html    <repo>/src/templates/
cp templates/weekly_flash_template.html   <repo>/src/templates/
cp templates/styles.css                   <repo>/src/templates/
```

### 2. Pipeline 側の追加（重要）
`styles.css` を docs/ に公開する必要があります。`step3_deploy.py` あたりで:
```python
import shutil
shutil.copy("src/templates/styles.css", "docs/styles.css")
```

### 3. Python 側のHTML生成関数の更新
従来のテンプレートとは**CSSクラス名が異なる**ため、`step2_report.py` / `step6_backtest.py` / `step_weekly_flash.py` の `{{...}}` プレースホルダー組み立て関数を更新してください。

各 `*_template.html` の末尾コメント `PYTHON 生成HTML 例` に、新スキーマに合わせたHTML雛形を載せてあります。それを参考に既存の組み立てロジックを書き換えるのが最短ルートです。

## プレースホルダー一覧

### `report_template.html`（月次）
従来名を保持しつつ、新規追加分を含めて以下：

| Placeholder | 役割 | 既存/新規 |
|---|---|---|
| `{{YEAR_MONTH}}` | "2026.05" 等 | 既存 |
| `{{GENERATED_DATE}}` | 生成日時 | 既存 |
| `{{ARCHIVE_LINKS}}` | アーカイブ`<a>`タグ | 既存 |
| `{{COVER_SECTION}}` | カバーヘッドライン（Gemini生成想定） | **新規** |
| `{{KPI_STRIP_SECTION}}` | 5項目KPI帯 | **新規** |
| `{{NEWS_STRATEGY_SECTION}}` | リード文（ドロップキャップ） | 既存（構造変更） |
| `{{SECTOR_WARNING_BANNER}}` | セクター警告（条件付き、空文字可） | 既存 |
| `{{PERFORMANCE_SECTION}}` | 前月号銘柄成績ミニカード | 既存（構造変更） |
| `{{THEME_SUMMARY_CARDS}}` | テーマサマリーカード | 既存（オプション、空文字可） |
| `{{THEME_RANKING_SECTIONS}}` | テーマ詳細 × N（一番大きい） | 既存（構造大幅変更） |
| `{{STOCK_COMPARISON_SECTION}}` | 銘柄比較（★評価） | 既存（構造変更） |
| `{{SUPPLY_CHAIN_SECTION}}` | サプライチェーン表 | 既存（構造変更） |
| `{{RISK_SCENARIOS_SECTION}}` | リスクシナリオ（テーマ内に内包したので空文字推奨） | 既存（非推奨） |
| `{{CHANGES_SECTION}}` | 前月レポートからの変化 | 既存 |
| `{{SOURCE_LINKS_SECTION}}` | 主要ソースリンク | 既存（構造変更） |
| `{{AI_MODELS_TEXT}}` | 使用モデル名 | 既存 |
| `{{CHART_INIT_SCRIPT}}` | Chart.js 株価チャート初期化 | 既存 |
| `{{CHAT_WIDGET_SECTION}}` | チャットウィジェット全体（既存の `{{CHAT_PROXY_URL}}` 周り） | **新規（既存をブロック化）** |

### `performance_template.html`
| Placeholder | 役割 | 既存/新規 |
|---|---|---|
| `{{UPDATED_AT}}` | 更新日時 | 既存 |
| `{{PERIOD_RANGE}}` | 集計期間 | 既存 |
| `{{HERO_RETURN_SECTION}}` | +X.X% の大見出し数値 | **新規** |
| `{{SUMMARY_CARDS}}` | 4項目KPIグリッド | 既存（構造変更） |
| `{{BEST_WORST_SECTION}}` | ベスト/ワースト銘柄カード | **新規** |
| `{{MONTHLY_TABLE_ROWS}}` | 月別分布バーの行 | 既存（構造変更） |
| `{{TOP_PICKS_SECTION}}` | ベストパフォーマー × 5 | **新規** |
| `{{THEME_FILTER_OPTIONS}}` | テーマフィルタopt | 既存 |
| `{{MONTH_FILTER_OPTIONS}}` | 月フィルタopt | 既存 |
| `{{STOCKS_TABLE_ROWS}}` | 個別銘柄テーブル行 | 既存（構造変更） |
| `{{CHART_LABELS}}`, `{{CHART_RETURNS}}` | Chart.js データ | 既存 |

### `weekly_flash_template.html`
| Placeholder | 役割 | 既存/新規 |
|---|---|---|
| `{{WEEK_LABEL}}` | "2026 W19" | 既存 |
| `{{GENERATED_DATE}}` | 生成日時 | 既存 |
| `{{DATE_RANGE}}` | "05.05 — 05.09" | 既存 |
| `{{MARKET_INDICES_SECTION}}` | マーケット指標ストリップ（日経/SP500/USDJPY/VIX） | **新規** |
| `{{SURGING_STOCKS_SECTION}}` | 急騰銘柄行 × 5 | 既存（構造大幅変更） |
| `{{EARNINGS_CALENDAR_SECTION}}` | 来週の決算予定 | **新規** |
| `{{TOP_NEWS_SECTION}}` | ヘッドライン × 3 | 既存（構造変更） |
| `{{MONTHLY_REPORT_URL}}` | 月次レポートへのリンク | 既存 |

## デザインシステム要点

| | |
|---|---|
| **ベース色** | 深紺 `#0d1626` |
| **アクセント** | ゴールド `#d4a341`、上昇緑 `#7dc679`、下落赤 `#e16158` |
| **見出しフォント** | Source Serif 4 / Noto Serif JP（イタリックで強調表現） |
| **本文フォント** | Inter / Noto Sans JP |
| **数字フォント** | JetBrains Mono（tabular-nums） |
| **絵文字** | 使わない、SVGアイコンに統一 |
| **対象デバイス** | スマホファースト（LINEから飛ぶ前提） |

## ローカルプレビュー

`Templates.html`（プロジェクトルート）を開けば、3レポートを並べた一覧から各プレビューに飛べます。
