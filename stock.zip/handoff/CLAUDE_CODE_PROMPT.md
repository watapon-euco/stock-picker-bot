# Claude Code 用 引き継ぎプロンプト

下記をそのままコピペして Claude Code に渡してください。
事前に `templates/` フォルダ（ZIP）を解凍して、リポジトリの `src/templates/` に配置 → 一度コミット＆プッシュしておくとスムーズです。

---

## プロンプト本文（ここから↓）

このリポジトリ `stock-picker-bot` のレポートUIを Editorial Dark テーマに刷新したい。新テンプレート4ファイル（`report_template.html` / `performance_template.html` / `weekly_flash_template.html` / `styles.css`）は既に `src/templates/` に配置済み。対応する Python 側のHTML生成コードを新CSSスキーマに合わせて書き換えてほしい。

### 背景

各テンプレートは従来同様の `{{PLACEHOLDER}}` 文字列置換方式だが、**Pythonが生成して埋め込むHTMLのCSSクラス名がすべて変わっている**。

新CSSは `.tp-*` プレフィックスで統一（例: `.tp-stock-row`, `.tp-theme`, `.tp-callout`, `.tp-monthly-row` など）。各テンプレートの末尾にコメントで「PYTHON 生成HTML 例」がついているので、それを正として組み立てロジックを書き直す。**着手前に必ず各テンプレートを読み込んで、末尾のスキーマ仕様を把握すること。**

### やってほしいこと

**1. テンプレートファイルの初回コミット**

Step 0 でダウンロード配置した4ファイルを「`feat: add new editorial-dark templates`」みたいなコミットメッセージで最初にコミット。これだけだとレポート生成は壊れる（プレースホルダー未置換）が、それで構わない。次以降のステップで Python 側を順次対応していく。

**1. CSS公開パイプライン追加**

`src/step3_deploy.py` に、`src/templates/styles.css` を `docs/styles.css` にコピーする処理を追加（既存の `docs/` 公開フローと同じタイミング）。`docs/weekly/styles.css` と `docs/archive/styles.css` への配置も忘れずに（各HTMLからの相対パスで参照しているため）。

**2. 月次レポート生成の書き換え** (`src/step2_report.py`)

新テンプレートのプレースホルダー一覧:

- `{{YEAR_MONTH}}`, `{{GENERATED_DATE}}`, `{{ARCHIVE_LINKS}}`, `{{AI_MODELS_TEXT}}` — 既存ロジックそのまま流用OK
- `{{COVER_SECTION}}` — **新規**。Gemini か Claude にカバーヘッドライン（3行に分かれた印象的なコピー、中央行は強調語）を生成させる。雛形は templates の末尾コメント [1] 参照。
- `{{KPI_STRIP_SECTION}}` — **新規**。5項目（テーマ数 / 銘柄数 / 1M Avg / 勝率 / 前月比）の `<div class="tp-stat-strip tp-stat-strip--5">` を組み立て。雛形 [2] 参照。
- `{{NEWS_STRATEGY_SECTION}}` — 構造変更。ドロップキャップ付きの `.tp-lede` を生成。雛形 [3] 参照。
- `{{SECTOR_WARNING_BANNER}}` — 構造変更。警告がある時のみ `.tp-callout--warn` を出力、無いなら空文字。雛形 [4] 参照。
- `{{PERFORMANCE_SECTION}}` — 構造変更。前月号銘柄の成績サマリー。雛形 [5] 参照。
- `{{THEME_RANKING_SECTIONS}}` — **構造大幅変更**。各テーマを `<article class="tp-theme">` でラップし、内部に `.tp-stock-row` × N + `.tp-score-bars`（5軸スコアの細バー）× N + `.tp-callout--risk` を含める。雛形 [6] 参照。**ここが一番工数大きい。**
- `{{STOCK_COMPARISON_SECTION}}` — 構造変更。`.tp-stars-table` で★評価表示。雛形 [7] 参照。
- `{{SUPPLY_CHAIN_SECTION}}` — 構造変更。`.tp-supply-table` で `.rel` チップ付き表示。雛形 [8] 参照。
- `{{RISK_SCENARIOS_SECTION}}` — テーマブロック内に内包したので、**空文字を返してOK**（後方互換のため残置）。
- `{{CHANGES_SECTION}}` — 既存ロジック流用、見た目だけ `.tp-callout` 等に揃える。
- `{{SOURCE_LINKS_SECTION}}` — 構造変更。`.tp-sources` + `.tp-sources__group` + `.tp-sources__link`。雛形 [9] 参照。
- `{{THEME_SUMMARY_CARDS}}` — オプション。冗長なら空文字でスキップしてOK。
- `{{CHART_INIT_SCRIPT}}` — 既存の Chart.js 初期化スクリプトを流用。ただし色は新パレットに合わせて変更:
  - 線色: `#7dc679`（緑） / `#e16158`（赤）
  - 背景塗り: `rgba(125,198,121,0.15)` / `rgba(225,97,88,0.15)`
  - 軸/グリッド: `#9aa3b8` / `rgba(255,255,255,0.05)`
- `{{CHAT_WIDGET_SECTION}}` — **新規**。既存の `{{CHAT_PROXY_URL}}` 周りのチャットウィジェット全体（FAB＋パネル＋CSS＋JS）を1ブロックにまとめてここに出力。`CHAT_PROXY_URL` 未設定なら空文字。チャットUIの見た目も新パレット（深紺地+ゴールドアクセント+セリフ見出し）にトーン合わせ。

スコアバー（5軸）の `data-width` 属性は必須。`templates/styles.css` には `width: 0%` で出して `IntersectionObserver` で展開するアニメーションが入っており、テンプレート本文のJSが拾う。

**3. パフォーマンスダッシュボード生成の書き換え** (`src/step6_backtest.py`)

プレースホルダー:

- `{{UPDATED_AT}}`, `{{PERIOD_RANGE}}` — 既存流用
- `{{HERO_RETURN_SECTION}}` — **新規**。`.perf-hero` ブロックで「+8.4%」みたいな大数値表示。雛形 [1] 参照。
- `{{SUMMARY_CARDS}}` — 構造変更。4項目（勝率 / 最大DD / 勝月 / 推奨数）の `.tp-kpi-grid`。雛形 [2] 参照。
- `{{BEST_WORST_SECTION}}` — **新規**。`.tp-best-worst` の2カラム。雛形 [3] 参照。
- `{{MONTHLY_TABLE_ROWS}}` — 構造変更。`.tp-monthly-row` × N。バーは中央 50% を起点に、ret>=0 なら右に、ret<0 なら左に伸ばす。`Math.max(Math.abs(...))` で正規化。雛形 [4] 参照。
- `{{TOP_PICKS_SECTION}}` — **新規**。`.tp-perf-row` × 5（1位だけ `--top`）。雛形 [5] 参照。
- `{{STOCKS_TABLE_ROWS}}` — 構造変更。`<tr>` に `data-theme` / `data-year_month` / `data-return_pct` 属性、`<td>` に `.col-month` / `.col-code` / `.col-name` / `.col-price` / `.col-return` クラス。雛形 [6] 参照。
- `{{CHART_LABELS}}`, `{{CHART_RETURNS}}` — そのまま流用OK。

**4. 週次速報生成の書き換え** (`src/step_weekly_flash.py`)

プレースホルダー:

- `{{WEEK_LABEL}}`, `{{GENERATED_DATE}}`, `{{DATE_RANGE}}`, `{{MONTHLY_REPORT_URL}}` — 既存流用
- `{{MARKET_INDICES_SECTION}}` — **新規**。4指標（日経平均 / S&P500 / USD/JPY / VIX）の `.tp-stat-strip--4`。yfinance で `^N225` / `^GSPC` / `JPY=X` / `^VIX` を取得して前日比%で表示。雛形 [3] 参照。
- `{{SURGING_STOCKS_SECTION}}` — **構造大幅変更**。`.tp-surge-row` × 5（1位だけ `--top`）。**各銘柄ごとにインラインSVGスパークラインを生成**する必要あり。5〜13点の終値配列を `width=44, height=20` の SVG path に変換する関数を作る。雛形 [1] 参照。
  - スパークライン生成のロジック例:
    ```python
    def make_spark_svg(values, w=44, h=20, color="#7dc679"):
        if not values: return ""
        mn, mx = min(values), max(values)
        rng = mx - mn or 1
        step = w / (len(values) - 1)
        pts = [(i*step, h - (v-mn)/rng*h) for i, v in enumerate(values)]
        path = " ".join(f"{'M' if i==0 else 'L'}{x:.1f},{y:.1f}" for i, (x,y) in enumerate(pts))
        return f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}"><path d="{path}" fill="none" stroke="{color}" stroke-width="1.3" stroke-linecap="round"/></svg>'
    ```
- `{{EARNINGS_CALENDAR_SECTION}}` — **新規**。来週決算予定の銘柄を `.tp-earnings-row` で列挙。既存の `src/utils/earnings_fetcher.py` をウォッチリスト + 前月推奨銘柄に対して走らせ、3日以内ではなく**7日以内**にフィルタ。雛形 [4] 参照。決算予定なしなら空文字。
- `{{TOP_NEWS_SECTION}}` — 構造変更。`<article class="tp-news">` × 3。雛形 [2] 参照。

### 品質基準

- **Python側のテストは必ず通す**: `tests/test_template.py` 等の既存テストを新スキーマに合わせて更新。新規追加した生成関数（特にスパークライン生成、KPI strip 生成、テーマブロック生成）には単体テストを追加。
- **新規プレースホルダーには必ずデフォルト値を用意**: 例えば `{{EARNINGS_CALENDAR_SECTION}}` は対象なしなら空文字、`{{SECTOR_WARNING_BANNER}}` も警告なしなら空文字。未置換の `{{...}}` がHTMLに残らないように。
- **既存の `src/utils/cost_logger.py` でAPIコストを記録する流れは維持**。カバーヘッドライン生成で追加のLLM呼び出しが入る場合もコストログに記録すること。
- **モバイル幅(390px)でレイアウトが崩れないこと**を、生成された docs/index.html / docs/performance.html / docs/weekly/最新号.html をローカルで開いて確認。
- **絵文字は使わない**。新デザインでは絵文字は全廃しSVGアイコンに置換済み。Python生成HTMLでも絵文字を出力しないこと。
- **コミットは機能単位で分ける**:
  1. `step3_deploy.py` への styles.css 公開追加
  2. `step2_report.py` の月次刷新
  3. `step6_backtest.py` のパフォーマンス刷新
  4. `step_weekly_flash.py` の週次刷新
  5. テスト追加・更新

### 着手前に確認したいこと

- カバーヘッドラインの生成に使うLLMはどちらにする？（Claude Sonnet 4.6 を推奨。既存の Batch API ではなく単発呼び出しが妥当）
- マーケット指標で取得失敗時の挙動（全部 — 表示 / セクション自体スキップ）

各テンプレートの末尾コメント（`PYTHON 生成HTML 例` セクション）が事実上のスキーマなので、迷ったらそこを正にしてください。完了後に最終結果のスクショ3枚（月次・パフォーマンス・週次）を貼って報告してください。

## プロンプト本文（ここまで↑）

---

## 補足

- このプロンプトはClaude Codeに**1回で全部投げる**前提で書いてあります。重い場合は「まず1番から」のように段階指示にしても可。
- 着手前に Claude Code に `templates/` ZIP を解凍して `src/templates/` に配置 → `feat: add new editorial-dark templates` でコミット済みの状態にしてから渡してください（このコミットだけだとレポート生成は一時的に壊れます）。
- 着手後に質問が出たら、デザインのプレビューHTML（`preview_*.html`）が同じZIPに入っているのでブラウザで見せてください。
- スコアバーアニメーションのJSは `report_template.html` の `<script>` ブロックに既に入れてあるので、Pythonからは `data-width` を吐くだけでOK。